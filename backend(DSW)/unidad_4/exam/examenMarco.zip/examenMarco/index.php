<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <header>
        <h1>Examen 1ª Evaluación DSW</h1>
    </header>


Por si necesitas hacer una consulta:
fetch(PDO::FETCH_ASSOC /*FETCH_OBJ*/)
    




	
    

    <p><b>Título:</b><?php echo " " ?> </p>
    <p><b>Autor:</b><?php echo " "?></p>
	
    <p> <button><a href="inicioSesion.php">Inicia sesión</a></button></p>
    <p><button><a href="formulariodealta.php">Registrarse</button></a>
    


<?php


?>









</body>
</html>
