
  <?php
        $servername="localhost";
        $username = "admin";
        $psswd = "1234";
        try {
            $conn = new PDO("mysql:host=$servername;dbname=examen_marco", $username, $psswd);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "Conexión Exitosa.<br>";
        } catch (PDOExecutable $e) {
            echo $e ," Conexión Fallida.<br>";
        }
    ?>
