<html>
<body>
    <h2><a href="index.html">VOLVER</a></h2>
<div class="info">
<?php
$color=$_POST['color'];
echo $color;
echo '<body style="background-color:' .$color. '">';
?>
</div>
</body>
</html>