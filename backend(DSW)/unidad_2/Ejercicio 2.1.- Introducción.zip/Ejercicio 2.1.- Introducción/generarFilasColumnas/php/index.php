<html>
<body>
    <h2><a href="../index.html">VOLVER</a></h2>
    <link rel="stylesheet" href="estilos.css">
<div class="info">
    <table>
<?php
$filas=$_POST['filas'];
$columnas=$_POST['columnas'];
$valor=$_POST['valor'];
$incremento=$_POST['incremento'];
for ($i = 0; $i < $filas; $i++) {
    echo "<tr>";
        for($x = 0; $x < $columnas; $x++){
            echo "<td>";
                echo $valor;
                $valor+=$incremento;
            echo "</td>";
        }
    echo "</tr>";
}
?>
</table>
</div>
</body>
</html>