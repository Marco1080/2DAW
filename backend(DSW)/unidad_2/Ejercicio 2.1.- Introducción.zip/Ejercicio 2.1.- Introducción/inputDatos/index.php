<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/formulario.css">
    <title>DATOS</title>
</head>
<body>
    <h2><a href="index.html">VOLVER</a></h2>
<div class="info">
<?php
$nombre=$_POST['nombre'];
$apellidos=$_POST['apellidos'];
$dni=$_POST['dni'];
$edad=$_POST['edad'];
$sueldo=$_POST['sueldo'];
$ipc=$_POST['ipc'];

echo "<p>Tu nombre es "  . $nombre. "</p>";
echo "<p>Tus apellidos son "  . $apellidos. "</p>";
echo "<p>Tu edad actual "  . $edad. "</p>";
echo "<p>Tu edad en 5 años sera "  . ($edad+5) . "años.</p>";
echo "<p>Tu DNI "  . $dni. "</p>";
echo "<p>Tu sueldo es "  . ($sueldo*$sueldo *$ipc/100) . "</p>";
?>
</div>
</body>
</html>