<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$value = isset($_POST['value']) ? $_POST['value']  : null;
$lista = array();
$pos = 0;
//GUARDAR EN UN ARRAY Y MOSTRAR CORREGIR
for($x=0; $x<=$value; $x++){
    if($x%2 == 0&&$x!=0){
        $lista[$x]=$x;
        echo "En la posicion ", $pos, " se encuentra ", $x, "<br>";
        $pos++;
    }
}
/*
foreach($lista as $dat){
    echo $dat, "<br>";
};
*/

?>
</body>
</html>