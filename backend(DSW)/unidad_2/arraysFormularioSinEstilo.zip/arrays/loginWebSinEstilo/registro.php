<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Registro</title>
</head>

<body>
    <?php
session_start();
$listado = array(
    array("marco","1234","admin")
);
if (isset($_SESSION['listado'])) { // COMPROBAMOS SI EXISTEN DATOS DEL LISTADO EN LA SESIÓN
    $listado = $_SESSION['listado']; // En caso de que sea así sobrrescribimos el array definido inicialmente
}

$intputName = isset($_POST['user']) ? $_POST['user'] : null;
$inputPass = isset($_POST['pass']) ? $_POST['pass'] : null;

guardarUsuario($intputName, $inputPass,$listado);

#imprimiendo todos los usuarios del array
foreach($listado as $x){
    echo $x[0] . " " . $x[1] . " " . $x[2] . "<br>";
}

#FUNCION PARA GUARDAR NUEVOS USUARIOS
function guardarUsuario($a,$b,&$listado){
    if($a!=""){
        foreach($listado as $x){
            if($x[0]==$a){
                exit("Ya existe el usuario usuario " . $x[0]."<br>");
            }
        }
        $listado[count($listado)] = array($a,$b,"user");
    }
}
function deleteUsers(){
    session_destroy();
}

$_SESSION['listado']= $listado;#compartir mediante el sesion valores del array

?>
    <form method="post">
        <table>
            <tr>
                <td id="titulo" colspan="2">REGISTRO</td>
            </tr>
            <tr>
                <td>USUARIO</td>
                <td><input type="text" name="user"></td>
            </tr>
            <tr>
                <td>CONTRASEÑA</td>
                <td><input type="text" name="pass"></td>
            </tr>
            <tr>
                <td><input type="reset"></td>
                <td><input type="submit"></td>
            </tr>
            <tr>
                <td>
                    <p>¿Ya tiene cuenta?</p>
                </td>
                <td><a href="inicio.php">Inicio de sesión</a></td>
            </tr>
            <tr><td colspan="2"><button onclick="deleteUsers()">Borrar sesiones</td></button></tr>
        </table>
        </fom>

</body>

</html>