<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Registro</title>

</head>

<body>
<?php
session_start();
$listado = $_SESSION['listado'];
$intputName = isset($_POST['user']) ? $_POST['user'] : null;
$inputPass = isset($_POST['pass']) ? $_POST['pass'] : null;
foreach($listado as $x){
    echo $x[0] . " " . $x[1] . " " . $x[2] . "<br>";
}
foreach($listado as $x){
    if($x[0]==$intputName && $x[1]==$inputPass){
        echo "ACCESO CONCEDIDO, USTED ES UN USUARIO DE TIPO: " . $x[2];
    }
}
?>
    <form method="post">
        <table>
            <tr>
                <td id="titulo" colspan="2">INICIO SESIÓN</td>
            </tr>
            <tr>
                <td>USUARIO</td>
                <td><input type="text" name="user"></td>
            </tr>
            <tr>
                <td>CONTRASEÑA</td>
                <td><input type="text" name="pass"></td>
            </tr>
            <tr>
                <td><input type="reset"></td>
                <td><input type="submit"></td>
            </tr>
            <tr>
                <td>
                    <p>¿No tiene cuenta?</p>
                </td>
                <td><a href="registro.php">Registrese</a></td>
            </tr>
        </table>
        </fom>

</body>

</html>