<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$v=$_POST['idioma'];
$x=$_POST['day'];
$en=array("lunes"=>"monday","martes"=>"tuesday",
        "miercoles"=>"wednesday", 
        "jueves"=>"thursday","viernes"=>"friday");

$fr=array("lunes"=>"lundi","martes"=>"mardi",
        "miercoles"=>"mercredi", 
        "jueves"=>"jeudi","viernes"=>"vendredi");

$il=array("lunes"=>"lunedi","martes"=>"martedi",
        "miercoles"=>"mercoledi", 
        "jueves"=>"giovedi","viernes"=>"venerdi");

switch($v){
    case "ingles": 
                foreach($en as $y => $z){
                    if($y==$x){
                        echo $x, " se dice ", $z, " en ", $v;
                    }
                }
        break;
    case "frances":
        foreach($fr as $y => $z){
            if($y==$x){
                echo $x, " se dice ", $z, " en ", $v;
            }
        }
        break;
    case "italiano":
        foreach($il as $y => $z){
            if($y==$x){
                echo $x, " se dice ", $z, " en ", $v;
            }
        }
        break;
}
?>
</body>
</html>