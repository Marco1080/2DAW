<?php

//CREAR VARIABLES PARA IGUALAR VALORES
if($_SERVER['REQUEST_METHOD']==='POST'){
session_start();

//COMPROBAMOS VALORES

//NOMBRE
$name = isset($_POST['name']) && !empty($_POST['name']) ? $_POST['name'] : null;

//APELLIDOS
$surname = isset($_POST['surname']) && !empty($_POST['surname']) ? $_POST['surname'] : null;

//TELEFONO
$phone = isset($_POST['phone']) && !empty($_POST['phone']) ? $_POST['phone'] : null;

//EDAD
$age = isset($_POST['age']) && !empty($_POST['age']) ? $_POST['age'] : null;

//PESO
$weight = isset($_POST['weigth']) && !empty($_POST['weigth']) ? $_POST['weigth'] : null;

//DIRECCION WEB
$web = isset($_POST['web']) && !empty($_POST['web']) ? $_POST['web'] : null;

//CORREOS
$mail = "";
$mail1 = isset($_POST['mail1']) && !empty($_POST['mail1']) ? $_POST['mail1'] : null;

$mail2 = isset($_POST['mail2']) && !empty($_POST['mail2']) ? $_POST['mail2'] : null;

if($mail1==$mail2){
    $mail=$mail1;
}

//INFO
$info = isset($_POST['info']) && !empty($_POST['info']) ? $_POST['info'] : null;
if($info==0){
    $info = "Sí";
}
elseif($info==1){
    $info ="No";
}

//FRUTA
$fruta = isset($_POST['fruta']) && !empty($_POST['fruta']) ? $_POST['fruta'] : null;

//SUGERENCIAS
$sugerencias = isset($_POST['sugerencias']) && !empty($_POST['sugerencias']) ? $_POST['sugerencias'] : null;

//FONDO
$fondo = isset($_POST['fondo']) && !empty($_POST['fondo']) ? $_POST['fondo'] : null;
echo $fondo;

//AFICION
$aficion = "";
if(isset($_POST['aficion'])){$aficion = $_POST['aficion'];}

//ARCHIVO
if($_SERVER['REQUEST_METHOD']==='POST'){
    $archivoImagen;
    if(file_exists($_FILES['archivo'])){
        $archivoImagen = $_FILES['archivo']["name"];
        $isUploaded = move_uploaded_file($_FILES['archivo']["tmp_name"],".");
    }
}

$_SESSION['aficion'] = $aficion;
$_SESSION['name']  = $name;
$_SESSION['surname']  = $surname;
$_SESSION['age']  = $age;
$_SESSION['weight']  = $weight;
$_SESSION['phone']  = $phone;
$_SESSION['web']  = $web;
$_SESSION['mail']  = $mail;
$_SESSION['info']  = $info;
$_SESSION['fruta']  = $fruta;
$_SESSION['sugerencias']  = $sugerencias;
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Formulario</title>

</head>

<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <?php include 'php/cabecera.php'?>
        <h1>FORMULARIO</h1>
        <fieldset>
            <legend>Datos Personales</legend>
            <table>
                <tr>
                    <td><label>Nombre:*</label></td>
                    <td><input type="text" name="name"></td>
                </tr>
                <tr>
                    <td><label>Apellidos:*</label></td>
                    <td><input type="text" name="surname"></td>
                </tr>
                <tr>
                    <td><label>Edad:</label></td>
                    <td>
                        <select name="age">
                            <option selected value="no mostrar">...</option>
                            <option value="10">10 años</option>
                            <option value="20">20 años</option>
                            <option value="30">30 años</option>
                            <option value="40">40 años</option>
                            <option>otro</option>
                        </select>
                    </td>
                </tr>
            </table>

            <table>
                <tr>
                    <td><label>Peso(Kg)</label></td>
                    <td><input type="number" name="weight"></td>
                </tr>
                <tr>
                    <td><label>Teléfono:*</label></td>
                    <td><input type="number" name="phone"></td>
                </tr>
                <tr>
                    <td><label>Página Web:</label></td>
                    <td><input type="text" name="web"></td>
                </tr>
            </table>

            <table>
                <tr>
                    <td><label>Indique su direccion de correo:*</label></td>
                    <td><input type="mail" name="mail1"></td>
                </tr>
                <tr>
                    <td><label>Confirme su direccion de correo:*</label></td>
                    <td><input type="mail" name="mail2"></td>
                </tr>
                <tr>
                </tr>
                <tr>
                    <td><label>Indique si desea recibir informacion adicional:</label></td>
                    <td>
                        <select name="info">
                            <option value="0">Si</option>
                            <option selected value="1">No</option>
                        </select>
                    </td>
                </tr>
            </table>
            <fieldset>
                <legend>Otros datos</legend>
                <label>Aficiones:</label>
                <input type="checkbox" id="cine" name="aficion[]" value="cine"><label for="cine">Cine</label>
                <input type="checkbox" id="lit" name="aficion[]" value="literatura"><label for ="lit">Literatura</label>
                <input type="checkbox" id="tb" name="aficion[]" value="tebeos"><label for="tb">Tebeos</label>
                <input type="checkbox" id="dp" name="aficion[]" value="deporte"><label for="dp">Deporte</label>
                <input type="checkbox" id="ms" name="aficion[]" value="musica"><label for="ms">Música</label>
                <input type="checkbox" id ="tv" name="aficion[]" value="television"><label for ="tv">Televisión</label>
                <table>
                    <tr>
                        <td><input type="radio" name="fruta" id="cereza" value="cereza"><label for="cereza">Cerezas</label></td>
                    </tr>
                    <tr>
                        <td><input type="radio" name="fruta" id="fr" value="fresa"><label for="fr">Fresas</label></td>
                    </tr>
                    <tr>
                        <td><input type="radio" name="fruta" id="lm" value="limon"><label for="lm">Limón</label></td>
                    </tr>
                    <tr>
                        <td><input type="radio" name="fruta" id="mz" value="manzana"><label for="mz">Manzana</label></td>
                    </tr>
                    <tr>
                        <td><input type="radio" name="fruta" id="nj" value="naranja"><label for="nj">Naranja</label></td>
                    </tr>
                    <tr>
                        <td><input type="radio" name="fruta" id="pr" value="pera"><label for="pr">Pera</label></td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <td><label>Cambia el estilo de la página</label></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="fondo" id="fondo" value="0"><label for="fondo">Color del fondo de la página</label></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="letra" id="color"><label for="color">Color de la letra de la página</label></td>
                    </tr>
                    <tr>
                        <td><input type="file" name="archivo"></td>
                    </tr>
                </table>
                <textarea placeholder="Sugerencias..." name="sugerencias"></textarea>
            </fieldset>
            <label>*Campos obligatorios</label><br>
            <input id="bot" type="submit">
            <input id="bot" type="reset">
            <button onclick="imprimir()">IMPRIMIR PDF</button>
            <script>
                function imprimir(){
                    window.print();
                };
            </script>
        </fieldset>
    </form>
    <?php include 'php/datos.php'?>
    <?php include 'php/footer.php'?>
</body>
</html>