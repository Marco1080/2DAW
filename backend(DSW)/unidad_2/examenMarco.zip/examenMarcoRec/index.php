<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos.css">
    <title>Inicio</title>
</head>
<body>
    <h1>Ingrese usuario y contraseña</h1>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
        <table>
            <tr>
                <td>Usuario</td>
                <td><input type="text" name="user" autocomplete="off"></td>
            </tr>
            <tr>
                <td>Contraseña</td>
                <td><input type="text" name="pass" autocomplete="off"></td>
            </tr>
            <tr>
                <td><input type="reset"></td>
                <td><input type="submit"></td>
            </tr>
        </table>
    </form>
    <?php
        $listado = [["marco_rec","marco@marco.es"],["jorge","jorge@jorge.es"]];
        $user = "";
        $pass = "";
        if($_SERVER['REQUEST_METHOD']=='POST'){
            if(isset($_POST['user']) && !empty($_POST['user'])){
                $user = limpiar($_POST['user']);
            }else{
                echo "Debe introducir un usuario";
            }
            if(isset($_POST['pass']) && !empty($_POST['pass'])){
                if(filter_var($_POST['pass'],FILTER_VALIDATE_EMAIL)){
                    $pass = limpiar($_POST['pass']);
                }else{
                    echo"<br>La contraseña debe ser formato email";
                }
            }else{
                echo "<br>Debe introducir una contraseña";
            }
            foreach($listado as $x){
                if($x[0]==$user && $x[1]==$pass){
                    echo"<br>Acceso concedido";
                    echo"<br><a href='php/tablas.php'>Ejercicio tablas</a>";
                    echo "<br><a href='php/factorial.php'>Ejercicio factorial</a>";
                }
            }
        }
        function limpiar($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
        return $data;
        }
    ?>
</body>
</html>