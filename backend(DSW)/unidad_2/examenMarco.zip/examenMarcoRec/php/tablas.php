<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Tabla</title>
</head>
<body>

    <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
        <table>
            <tr>
                <td>Nº filas</td>
                <td><input type="text" name="filas" autocomplete="off"></td>
                <td>Altura</td>
                <td><input type="text" name="altura" autocomplete="off"></td>
            </tr>
            <tr>
                <td>Nº columnas</td>
                <td><input type="text" name="columnas" autocomplete="off"></td>
                <td>Anchura</td>
                <td><input type="text" name="anchura" autocomplete="off"></td>
            </tr>
            <tr><td colspan="4"><input type="submit"></td></tr>
        </table>
    </form>
    <a href="../index.php">Volver</a>
    <br><br>
    <?php
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $numeroFilas = "";
            $altura = "";
            $anchura = "";
            $columnas = "";
            if(isset($_POST['filas']) && !empty($_POST['filas'])){
                $filas = limpiar($_POST['filas']);
                $numeroFilas = strlen($filas);
            }else{
                echo"<br>Ingrese número de filas";
            }

            if(isset($_POST['altura']) && !empty($_POST['altura'])){
                if(filter_var($_POST['altura'],FILTER_VALIDATE_INT)){
                    $altura = limpiar($_POST['altura']);
                }else{echo"<br>La altura debe ser un número entero";}
            }else{
                echo"<br>Ingrese número de altura";
            }

            if(isset($_POST['columnas']) && !empty($_POST['columnas'])){
                if(filter_var($_POST['columnas'],FILTER_VALIDATE_INT)){
                    $columnas = limpiar($_POST['columnas']);
                }else{echo"<br>Las columnas deben ser un número entero";}
            }else{
                echo"<br>Ingrese número de columnas";
            }

            if(isset($_POST['anchura']) && !empty($_POST['anchura'])){
                if(filter_var($_POST['anchura'],FILTER_VALIDATE_INT)){
                    $anchura = limpiar($_POST['anchura']);
                }else{echo"<br>La anchura debe ser un número entero";}
            }else{
                echo"<br>Ingrese número de anchura";
            }
            if($numeroFilas != "" && $columnas != "" && $anchura != "" && $altura != ""){
                creartabla($numeroFilas,$columnas,$altura,$anchura);
            }
        }
        function creartabla($filas,$columnas,$altura,$anchura){
            $u = $filas;
            echo "<table border='4px' " . "width='" . $anchura . "px' ". "height='" . $altura . "px' ".">";
                echo "<tr>";
                    do{
                        echo "<td></td>";
                        for($i = 1; $i <= $columnas; $i++){
                            echo "<td class='indice'>";
                                echo $i;
                            echo "</td>";
                        }
                echo "</tr>";
                        for($x = 1; $x <= $filas; $x++){
                            echo "<tr>";   
                                echo "<td class='indice'>";
                                    echo $x;
                                echo "</td>";
                                for($z = 0; $z < $columnas; $z++){
                                        echo "<td>";
                                                echo $u;
                                                $u += 5;
                                        echo "</td>";
                                    }
                            echo "</tr>";
                        }
                    }while(0>1);
            echo "</table>";
        }
        function limpiar($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
        return $data;
        }
    ?>
</body>
</html>