<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../estilos.css">
    <title>Factorial</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
        <table>
            <tr>
                <td>Número a refactorizar</td>
                <td><input type="text" name="number"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit"></td>
            </tr>
        </table>
        <a href="../index.php">Volver</a>
        <br><br>
    </form>
    <?php
        if($_SERVER['REQUEST_METHOD']=='POST'){
            if(isset($_POST['number']) && !empty($_POST['number'])){
                if(filter_var($_POST['number'],FILTER_VALIDATE_INT)){
                    $number = limpiar($_POST['number']);
                    factorizar($number);
                }else{
                    echo "<br>Debe introducir un número entero.";
                }
            }else{
                echo "<br>Introduzca un número.";
            }
        }
        function factorizar($x){
            echo "El factorial de " . $x . " = " . $x;
            $contador = 1;
            for($i = 1; $i < $x; $x--){
                $contador *= $x;
                echo " x ". $x-1; 
            }
            echo " = " .$contador;
        }
        function limpiar($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
        return $data;
        }
    ?>
</body>
</html>