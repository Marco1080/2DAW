<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
</head>
<body>
    <?php
    if($_SERVER['REQUEST_METHOD']==='POST'){
    $name = $_SESSION['name'];
    $surname = $_SESSION['surname'];
    $age = $_SESSION['age'];
    $mail = $_SESSION['mail'];
    $phone = $_SESSION['phone'];
    $web = $_SESSION['web'];
    $info = $_SESSION['info'];
    $sugerencias = $_SESSION['sugerencias'];
    $fruta = $_SESSION['fruta'];
    echo 
    "<div class='content'>"
        ."Tu nombre es ". $name ."<br>"
        ."Tus apellidos son: ". $surname ."<br>"
        ."Tienes  ".$age ." años" ."<br>"
        ."Su dirección de correo es: " . $mail ."<br>"
        . $info . " recibirá correos nuestros." ."<br>"
        ."Su teléfono es: " .$phone ."<br>"
        . "Su página web es: " .$web ."<br>"
        . "Tus aficiones son: " ."<br>"
        . "Tu fruta favorita es: " .$fruta."<br>"
        . "<img src='media/" . $fruta . ".png' widh='200px' height='200px'>"."<br>"
        . "Su comentario es : " . $sugerencias
        . 
    "</div>";
    }
    ?>
</body>
</html>