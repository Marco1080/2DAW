const valor1 = document.getElementById("valor1");
const valor2 = document.getElementById("valor2");
const valor3 = document.getElementById("valor3");

let n1 = 0;
let n2 = 0;
let n3 = "";
let n4 = "";

valor1.addEventListener("input",updateN1);
valor2.addEventListener("input",updateN2);
valor3.addEventListener("input",updateN3);
valor4.addEventListener("input",updateN4);

function updateN1(e){
    n1 = e.target.value;
    evaluacion();
}
function updateN2(e){
    n2 = e.target.value;
    document.getElementById("edad").innerHTML = parseInt(n2);
}
function updateN3(e){
    n3 = e.target.value;
    n4 = "";
    document.getElementById("genero1").innerHTML = n3;
}
function updateN4(e){
    n4 = e.target.value;
    n3 = "";
    document.getElementById("genero1").innerHTML = n4;
}
function frecuencia(){
    if(n3=="" && n4==""){
        document.getElementById("frecuencia").innerHTML ="RITMO CARDIACO", 5;
    }
}
frecuencia();

function evaluacion(){
    n1 = parseInt(n1);
    if(n1<16 && n1!=0){
        document.getElementById("peso").innerHTML = "Delgadez severa.";
        document.getElementById("peso").style.color ="red";
        document.getElementById("peso").style.textDecoration ="none";
    }
    else if(n1>=16 && n1<16.99){
        document.getElementById("peso").innerHTML = "Delgadez moderada.";
        document.getElementById("peso").style.color ="orange";
        document.getElementById("peso").style.textDecoration ="none";
    }
    else if(n1>=17 && n1<18.49){
        document.getElementById("peso").innerHTML = "Delgadez aceptable.";
        document.getElementById("peso").style.color ="yellow";
        document.getElementById("peso").style.textDecoration ="none";
    }
    else if(n1>=18.49 && n1<24.99){
        document.getElementById("peso").innerHTML = "Peso normal.";
        document.getElementById("peso").style.color ="green";
        document.getElementById("peso").style.textDecoration ="underline";
    }
    else if(n1>=24.99 && n1<29.99){
        document.getElementById("peso").innerHTML = "Sobrepeso.";
        document.getElementById("peso").style.color ="blue";
        document.getElementById("peso").style.textDecoration ="underline";
    }
    else if(n1>=29.99 && n1<34.99){
        document.getElementById("peso").innerHTML = "Obeso Tipo I.";
        document.getElementById("peso").style.color ="yellow";
        document.getElementById("peso").style.textDecoration ="underline overline";
    }
    else if(n1>=35.00 && n1<40.00){
        document.getElementById("peso").innerHTML = "Obeso tipo II.";
        document.getElementById("peso").style.color ="orange";
        document.getElementById("peso").style.textDecoration ="underline overline";
    }
    else if(n1>=40.00 ){
        document.getElementById("peso").innerHTML = "BUSCA AYUDA.";
        document.getElementById("peso").style.color ="red";
        document.getElementById("peso").style.textDecoration ="underline overline";
    }
    else{
        document.getElementById("peso").innerHTML = "ESPERANDO VALOR...";
        document.getElementById("peso").style.color ="white";
        document.getElementById("peso").style.textDecoration ="none";
    }

}
evaluacion();