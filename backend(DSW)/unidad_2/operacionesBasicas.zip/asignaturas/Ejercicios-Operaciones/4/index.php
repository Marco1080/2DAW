<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilophp.css">
</head>
<body>
    <a href="index.html">INDICE</a>
    <?php
    error_reporting(0);
    $number=$_POST['number'];
    $number2=$_POST['number2'];
    $operacion=$_POST['operacion'];
    switch($operacion){
        case "suma": echo "<br>" ,$number+$number2;
            break;
        case "resta": echo "<br>",$number + $number2;
            break;
        case "multiplicacion": echo "<br>",$number*$number2;
            break;
        case "division": if($number2==0)echo "<br>INDETERMINADO" ;
                        else{echo "<br>",$number / $number2;}
            break;
        default:    
            break;
    }
    ?>
</body>
</html>