<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilophp.css">
</head>
<body>
    
<a href="index.html">INDICE</a>
    <div class="bloque">
    <?php
    error_reporting(0);
    if (empty($_POST['number'])) {
        echo "No me has puesto nada :(";
        return;
    } else {
        $number=$_POST['number'];
    }
    if($number==0){echo "BRO DA 0 ";
    }else{
        for($i=0;$i<=10;$i++){
            echo "<br>",$number, " X " ,$i, " = ", ($number*$i);
        }
    }
    ?>
    </div>
</body>
</html>