<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="icons/style.css">
    <title>Formulario</title>
<body>
    <link rel="stylesheet" href="estilos.css">
<div class="info">
    <body>
        <table>
        <video src="media/Lago - 91562.mp4" autoplay muted loop></video>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <table>
                <tr>
                    <td><label class="lbl-nombre"><span class="text-nomb">USUARIO / marco</span></label></label></td>
                    <td><input type="text" name="usuario"></td>
                </tr>

                <tr>
                    <td><label class="lbl-nombre"><span class="text-nomb">CONTRASEÑA / 1080</span></label></label></td>
                    <td><input type="text" name="contraseña"></td>
                </tr>

		        <tr>
                     <td><input class="hover-center-1" type="reset" value="BORRAR"></td>
                     <td><input class="hover-center-1" type="submit" value="ENVIAR"></td>
                </tr>
            </table>
         </form>
         <div class="salir">
            <a href="../../index.html"><span class="icon-arrow-thick-left"></span></a>
         </div>
 <script src="javascript/main.js"></script>
<?php
error_reporting(0);
$usuario=$_POST['usuario'];
$contraseña=$_POST['contraseña'];
$user = "marco";
$password = "1080";
if(empty($usuario)||empty($contraseña)){
    echo "";
}else{
    if($usuario!=$user && $contraseña!=$password){
        echo "<p>USUARIO Y CONTRASEÑA ERRONEOS</p>";
    }
    else if($usuario!=$user && $contraseña==$password){
        echo "<p>USUARIO ERRONEO</p>";
    }
    else if($usuario===$user && $contraseña!=$password){
        echo "<p>CONTRASEÑA ERRONEA</p>";
    }
    else if($usuario===$user && $contraseña===$password){
        header("Location: ../index.html");
    }
}


?>
</table>
</div>
</body>
</html>