<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../css/galery.css">
    <link rel="stylesheet" href="../icons/style.css">
    <script src="anime.min.js"></script>
    <title>Producto</title>
</head>
<body>
<a href="index.php"><span class="icon-arrow-left"></span></a>
    <?php
    include('../admin/includes/conec.php');
    $id = $_GET['id'];
    $sql = "select * from productos where id = $id";
    $resultado = $conn->query($sql);
    $x = $resultado->fetch();
    echo "<table class='table'>";
        echo "<thead class='thead-dark'>";
            echo "<tr>";
                echo "<th scope='col'>Nombre</th>";
                echo "<th scope='col'>Precio</th>";
                echo "<th scope='col'>Stock actual</th>";
            echo "</tr>";

            echo "<tr>";
                echo "<td scope='col'>" . $x['nombre'] . "</td>";
                echo "<td scope='col'>" . $x['precio'] . "€ </td>";
                echo "<td scope='col'>" . $x['stock'] . " unidad/es</td>";
            echo "</tr>";
        echo "</thead>";
    echo "</table>";
    $sql = "select * from imagenes_productos where id_producto = $id";
    $resultado = $conn->query($sql);
    echo "<div class='column'>";
        foreach($resultado as $x){
            echo "<img src='../photos/$x[2]' alt='imagen'>";
        }
    echo "</div>";
?>
</body>
</html>