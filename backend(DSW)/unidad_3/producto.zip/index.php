<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../css/product.css">
    <link rel="stylesheet" href="../icons/style.css">
    <title>Productos</title>
</head>

<body>
    <a href="../index.html"><span class="icon-arrow-left"></span></a>
    <div class="container-fluid">
        <div class="content">
        <?php
            include('../admin/includes/conec.php');
            $resultado = $conn->prepare("SELECT * FROM productos INNER JOIN imagenes_productos group by productos.id;");
            $resultado->execute();
            while($x=$resultado->fetch()){
                if($x['activado'] == 1){
                    $imagen = $conn->query("select nombre_archivo from imagenes_productos where id_producto=$x[0]")->fetch();
                    echo "<div class='card' style='width: 18rem;'>";
                        echo "<a href=\"producto.php?id= " . $x[0] ."\">"."<img src=' " ."../photos/" .$imagen[0] ."'" . "class='card-img-top'>" ."</a>";
                        echo "<div class='card-body'>";
                            echo "<h5 class='card-title'>" . $x['nombre'] . "</h5>";
                            echo "<p class='card-text'>".$x['descripcion']."</p>";
                            echo "<a href='#' class='btn btn-primary'>Añadir</a>";
                        echo "</div>";
                    echo"</div>";
                }
            }
        ?>
        </div>
    </div>
</body>

</html>