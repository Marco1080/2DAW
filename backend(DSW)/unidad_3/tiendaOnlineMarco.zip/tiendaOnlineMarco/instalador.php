<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tienda_online_marco";
try{
    $conn = new PDO("mysql:host=$servername", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "CREATE DATABASE IF NOT EXISTS tienda_online_marco";
    $conn->exec($sql);
    echo"<br>BASE DE DATOS '" .$dbname. "' CREADA CON ÉXITO<br>";
    
  $sql = file_get_contents("tienda_online_marco.sql");
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "Base de datos ${dbname} creada correctamente.";
}
catch(PDOException $e){
    echo $sql . "<br>" . $e->getMessage();
}
$conn = null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>