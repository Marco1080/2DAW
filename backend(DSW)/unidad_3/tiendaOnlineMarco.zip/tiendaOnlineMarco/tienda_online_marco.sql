use tienda_online_marco;
CREATE TABLE `Cliente` (
  `id_cliente` INT(6) PRIMARY KEY AUTO_INCREMENT,
  `usuario` VARCHAR(30) NOT NULL,
  `clave` VARCHAR(30) NOT NULL,
  `email` VARCHAR(50) NOT NULL,
  `telefono` int,
  `direccion` varchar(50)
);

CREATE TABLE `Pedido` (
  `id_pedido` INT(6) PRIMARY KEY AUTO_INCREMENT,
  `precio` int,
  `listado` varchar(24),
  `fechaEntregaEstimada` date,
  `id_cliente` INT(6)
);

CREATE TABLE `Proveedor` (
  `id_proveedor` INT(6) PRIMARY KEY AUTO_INCREMENT,
  `nombre` varchar(20),
  `direccion` varchar(50)
);

CREATE TABLE `Producto` (
  `id_producto` INT(6) PRIMARY KEY AUTO_INCREMENT,
  `nombre` varchar(20),
  `descripcion` varchar(100),
  `tipo` varchar(50),
  `stock` int(10),
  `precio` int(6)
);

CREATE TABLE `PedidoProducto` (
  `id_pedido` INT(6),
  `id_producto` INT(6),
  PRIMARY KEY (`id_pedido`, `id_producto`)
);

CREATE TABLE `ProductoProveedor` (
  `id_proveedor` INT(6),
  `id_producto` INT(6),
  PRIMARY KEY (`id_proveedor`, `id_producto`)
);

ALTER TABLE `Pedido` ADD FOREIGN KEY (`id_cliente`) REFERENCES `Cliente` (`id_cliente`);

ALTER TABLE `PedidoProducto` ADD FOREIGN KEY (`id_pedido`) REFERENCES `Pedido` (`id_pedido`);

ALTER TABLE `PedidoProducto` ADD FOREIGN KEY (`id_producto`) REFERENCES `Producto` (`id_producto`);

ALTER TABLE `ProductoProveedor` ADD FOREIGN KEY (`id_producto`) REFERENCES `Producto` (`id_producto`);

ALTER TABLE `ProductoProveedor` ADD FOREIGN KEY (`id_proveedor`) REFERENCES `Proveedor` (`id_proveedor`);
