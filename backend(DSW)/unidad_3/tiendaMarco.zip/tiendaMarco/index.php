<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
                <div class="col-12 navegacion">
                    <header>
                        <div class="logo"><a href=""><img src="media/cosmere.png"></a></div>
                        <nav>
                            <ul>
                                <li><a href="">HOME</a></li>
                                <li><a href="">PRODUCTS</a></li>
                                <li><a href="">ABOUT US</a></li>
                                <li><a href="">CONTACT</a></li>
                            </ul>
                        </nav>
                    </header>
                </div>
        
        <div class="col-12 portada">
            <h1>“Lo más grande es el espacio, porque lo encierra todo.”</h1>
        </div>
            <div class="col-8 offset-2 contenido">
                <h1 class="col-12">Products</h1>
                <?php include('php/conecta.inc')?>
            </div>
        </div>
    
        
            <div class="col-12 footer">
                <footer>© 2022 PLANET SHOP®, SSL.</footer>
            </div>
        </div>
    </div>
</div> 

</body>
</html>
