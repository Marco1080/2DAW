/*-------->CALCULADORA IMC<---------*/
/*PEDIR VALORES A LOS ID*/
let peso = document.getElementById("peso");
let altura = document.getElementById("altura");

/*INICIALIZAR VARIABLES CON VALORES*/
let p = 0;
let a = 0;
let resultado = 0;

const valoracionOutput = document.getElementById("valoracion");

/*AÑADIMOS LOS EVENT LISTENER PESO*/
peso.addEventListener("input",updatePeso);
function updatePeso(e){
    p = e.target.value;
    mostrar();
    resultadoColor();
}
function mostrar(){
    resultado = (p/(a**2)).toFixed(2);
    document.getElementById("result1").innerHTML = resultado;
}
/*AÑADIMOS LOS EVENT LISTENER ALTURA*/
altura.addEventListener("input",updateAltura);
function updateAltura(e){
    a = e.target.value;
    a = a/100;
    mostrar();
    resultadoColor();
}
function resultadoColor(){
    if(resultado>0 && resultado <16){
        valoracionOutput.innerHTML = resultado + " DELGADEZ SEVERA";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "red";
    }else if(resultado>=16 && resultado <16.99){
        valoracionOutput.innerHTML = resultado + " DELGADEZ MODERADA";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "orange";
    }if(resultado>=16.99 && resultado <18.49){
        valoracionOutput.innerHTML = resultado + " DELGADEZ ACEPTABLE";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "#BAB555";
    }else if(resultado>=18.49 && resultado <24.99){
        valoracionOutput.innerHTML = resultado + " PESO STANDARD";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "green";
    }else if(resultado>=24.99 && resultado <29.99){
        valoracionOutput.innerHTML = resultado + " SOBREPESO";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "blue";
    }else if(resultado>=29.99 && resultado <34.99){
        valoracionOutput.innerHTML = resultado + " OBESO TIPO I";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "#BAB555";
    }else if(resultado>=34.99 && resultado <40){
        valoracionOutput.innerHTML = resultado + "OBESO TIPO II";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "orange";
    }else if(resultado>40){
        valoracionOutput.innerHTML = resultado + " OBESO III";
        valoracionOutput.style.transition = "all 1.5s";
        valoracionOutput.style.backgroundColor = "red";
        
        
    }
    
}
/*-------->CALCULADORA FMC<---------*/
let edad = document.getElementById("edad");
let sexoManInput = document.getElementById("hombre");
let sexoWomanInput = document.getElementById("mujer");

let ed = 0;
let se = 0;
let frec = 0;
/*EDAD*/
const valoracion2Output = document.getElementById("valoracion2");
edad.addEventListener("input",updateEdad);
function updateEdad(e){
    ed = e.target.value;
    document.getElementById("result1").innerHTML = resultado;
    calculo();
}
sexoManInput.addEventListener("change",updateSexo);
sexoWomanInput.addEventListener("change",updateSexo);
function updateSexo(e){
    se = e.target.value;
    console.log(se);
    calculo();
}

function calculo(){
    
    if(se==0){
        frec = (224-ed).toFixed(2);
        document.getElementById("valoracion2").innerHTML = frec + " P/M";
        document.getElementById("rec").innerHTML =  (frec*0.6).toFixed(2) + " - " + (frec*0.7).toFixed(2);
        document.getElementById("aer").innerHTML =  (frec*0.7).toFixed(2) + " - " + (frec*0.8).toFixed(2);
        document.getElementById("anae").innerHTML =  (frec*0.8).toFixed(2) + " - " + (frec*0.9).toFixed(2);
        document.getElementById("linea").innerHTML =  (frec*0.9).toFixed(2) + " - " + (frec*1.0).toFixed(2);
    }
    else if(se==1){
        frec = (220-ed).toFixed(2);
        document.getElementById("valoracion2").innerHTML = frec + " P/M";
        document.getElementById("rec").innerHTML =  (frec*0.6).toFixed(2) + " - " + (frec*0.7).toFixed(2);
        document.getElementById("aer").innerHTML =  (frec*0.7).toFixed(2) + " - " + (frec*0.8).toFixed(2);
        document.getElementById("anae").innerHTML =  (frec*0.8).toFixed(2) + " - " + (frec*0.9).toFixed(2);
        document.getElementById("linea").innerHTML =  (frec*0.9).toFixed(2) + " - " + (frec*1.0).toFixed(2);
    }
}

/*-------->CALCULADORA CATEGORÍA<---------*/

let edad2 = document.getElementById("edad2");
let ed2 = 0;

const valoracion3Output = document.getElementById("valoracion3");
edad2.addEventListener("input",updateEdad2);
function updateEdad2(e){
    ed2 = e.target.value;
    otorgarCategoria();
}
valoracion3Output.innerHTML(ed2);

//
function otorgarCategoria(){
    if(ed2>=6 && ed2<=7 ){
        valoracion3Output.innerHTML = "Prebenjamín";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#EC7A8F";
    }else if(ed2>8 && ed2<=9){
        valoracion3Output.innerHTML = "Bengamín";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#E763D1";
    }else if(ed2>=10 && ed2<=11){
        valoracion3Output.innerHTML = "Alevín";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#8963E7";
    }else if(ed2>=12 && ed2<=13){
        valoracion3Output.innerHTML = "Infantil";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#2B67D8";
    }else if(ed2>=14 && ed2<=15){
        valoracion3Output.innerHTML = "Cadete";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#2BD8D0";
    }else if(ed2>=16 && ed2<=17){v
        aloracion3Output.innerHTML = "Junior";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#6CE378";
    }else if(ed2>=18 && ed2<=21){
        valoracion3Output.innerHTML = "Sub";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#A44588";
    }else if(ed2>=22){
        valoracion3Output.innerHTML = "Senior";
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#F76750";
    }else{
        valoracion3Output.style.transition = "all 1.5s";
        valoracion3Output.style.backgroundColor = "#DBD1D3";
    }
}
