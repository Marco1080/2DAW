
function verificarDni(){
    var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
    
        do{
            var entrada = window.prompt("Introduzca su DNI: ");
            var letra = entrada.slice(8,9);
        }while(entrada.length!=9);
            
            var valor = entrada.slice(0,8);
            var num = valor % 23;
            
        if(letra==letras[num]){
            document.write("<br>Su DNI ha sido verificado.");
            seguir = false;
        }else{document.write("<br>Su DNI es incorrecto.");}
        seguir = false;
}
verificarDni();