const saludar = () => {
        document.body.style.backgroundColor = "#E68975";
}



        window.alert("Bienvenido");
        let dato = 0;
        while(dato<=0 || isNaN(dato)==true){
            dato = window.prompt("Numero de personas: ","0");
        }
        document.getElementById("numero").innerHTML = "Receta para "+dato+" personas.";
        document.getElementById("harina").innerHTML = dato*1/2;
        if(dato*8>1000){
            document.getElementById("levadura").innerHTML = (dato*8)/1000;
            document.getElementById("unidadLevadura").innerHTML = "KILOGRAMOS de levadura seca de panadería";
        }
        else{
            document.getElementById("levadura").innerHTML = dato*8;
            document.getElementById("unidadLevadura").innerHTML = "GRAMOS de levadura seca de panadería";
        }
        document.getElementById("agua").innerHTML = dato*400;
        document.getElementById("sal").innerHTML = dato*1;

        let cambioColor = document.getElementById("boton");
        


