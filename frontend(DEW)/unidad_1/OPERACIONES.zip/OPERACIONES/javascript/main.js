var dato = 0;
function pedirDato(){
    dato = window.prompt("Elija un numero: ","0");
    return dato;
}
function multiplicar(dato){
    document.write("<hr>");
    document.write("<h1>TABLA DE MULTIPLICAR</h1>")
    for(let i = 0; i<= 10;i++){
        document.write(dato+ " X " + i + " = " + i * dato + "<br>");
    }
    document.write("<hr>");
}

function sumar(dato){
    dato=parseInt(dato);
    document.write("<hr>");
    let i = 0;
    document.write("<h1>TABLA DE SUMAR</h1>")
    while(i<=10){
        document.write("<br>")
        document.write("El resultado de  ",dato," + ",i," es ", i + dato);
        i++;
    }
    document.write("<hr>");
}

function dividir(dato){
    dato=parseInt(dato);
    document.write("<hr>");
    let i = 0;
    document.write("<h1>TABLA DE DIVIDIR</h1>")
    do{
        document.write("<br>")
        document.write("El resultado de  ",dato,"/",i," es ", (i /dato));
        i++;
    }while(i<=10);
    document.write("<hr>");
}
function operaciones(){
    document.write("<h1>OPERACIONES</h1><br>");
    document.write("<br>",125>>3);
    document.write("<br>",40<<2);
    document.write("<br>",25>>1);
    document.write("<br>",10<<4);
}

multiplicar(pedirDato()); 
sumar(dato); 
dividir(dato);
operaciones();