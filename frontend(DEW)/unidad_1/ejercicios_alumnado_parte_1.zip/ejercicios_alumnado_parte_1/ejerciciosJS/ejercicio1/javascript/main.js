/*
Ejercicio 1: Realiza una página en la que crees dos variables “string”, las 
“sumes” e imprimas el resultado.
*/
var x = "hola";
var y = " mundo";
document.write(x + y);
