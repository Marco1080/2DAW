/*
Ejercicio 3: Vamos a realizar una pequeña página que pida al usuario un 
par de números y mediante una condicional le digamos si el primero es mayor que 
el segundo o es menor o iguales. Es importante recordar que hemos de cambiar el 
tipo de string a int usando la función parseInt();
*/
var value_1 = prompt("Introduzca el primer valor: ");
var value_2 = prompt("Introduzca el segundo valor: ");
if(value_1==value_2){
    document.write("Son iguales.")
}
else if(value_1>value_2){
    document.write("El primer valor es mayor.");
}else{
    document.write("El segundo valor es mayor.");
}