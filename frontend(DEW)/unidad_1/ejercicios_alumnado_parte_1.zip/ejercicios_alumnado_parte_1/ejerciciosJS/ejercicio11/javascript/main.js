/*
Ejercicio 10: Hacer una Página web que genere una pirámide de 1 a 50, 
formada de la siguiente forma:
1 
22 
333 
4444 
55555 
666666 
7777777 
....... 

*/
for(var i=0;i<=50;i++){
    for(var x = 1;x<=i;x++){
        document.write(x);
    }
    
    document.write("<br>");
}