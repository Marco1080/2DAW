/*
Ejercicio 8: Realizar un programa que solicite al usuario un valor, y 
presente en pantalla la cuenta atrás y luego la cuenta hacia delante. Hacerlo con un 
bucle for.

*/
var x = prompt("Introduzca un valor: ");
for(var i=x;i>0;i--){
    document.write(i,"<br>");
}
document.write("<hr>");
for(i;i<=x;i++){
    document.write(i,"<br>");
}