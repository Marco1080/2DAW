/*
Ejercicio 9: El mismo anterior pero con bucle while.
*/
var x = prompt("Introduzca un valor: ");
var i = x;
while(i>0){
    document.write(i,"<br>");
    i--;
}
document.write("<hr>");
while(i<=x){
    document.write(i,"<br>");
    i++;
}
