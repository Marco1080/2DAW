/*
Ejercicio 7: Veamos el mismo ejemplo anterior del bucle for, pero con un 
while.
*/
var i = 6;

while(i>0){
    document.write("<h" + i + ">Encabezado " + i + " </h"+i+">");
    i--;
}
