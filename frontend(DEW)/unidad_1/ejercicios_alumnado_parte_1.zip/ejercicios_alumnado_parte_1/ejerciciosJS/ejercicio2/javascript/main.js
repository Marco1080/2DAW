/*
Ejercicio 2: La función typeof() devuelve el tipo de una variable. Hacer un 
script que te diga el tipo de un par de variables, sin inicializarlas y posteriormente 
con un valor (string, number y boolean).
*/
document.write(typeof(5),"<br>");

var x;
document.write(typeof(x));
var x = "hola mundo";
var y = 9;
var z = true;
document.write("<br>","<hr>","<br>",typeof(x),"<br>",typeof(y),"<br>",typeof(z));