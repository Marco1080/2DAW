/*
Ejercicio 4: Veamos otro ejemplo sencillo que nos ilustra sobre el manejo 
del if. Este script nos devuelve “hola” si no introducimos nada o aquello que hemos 
escrito. 
*/
var value_1 = prompt("Introduzca texto: ");
if(value_1==""){
    document.write("hola");
}
else{
    document.write(value_1);
}