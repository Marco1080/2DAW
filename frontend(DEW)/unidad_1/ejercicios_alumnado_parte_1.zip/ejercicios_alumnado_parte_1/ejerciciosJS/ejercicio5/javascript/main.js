/*
Ejercicio 5: Hay un formato para el if que se utiliza mucho en 
determinadas ocasiones y que nos ayuda a poner nuestro código más claro.
/* otra forma del if sería:
 (final==null ? document.write("Hola"): document.write(final));
*/
