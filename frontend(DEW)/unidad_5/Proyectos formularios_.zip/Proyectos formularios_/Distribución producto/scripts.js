const fecha = document.getElementById("fecha");
fecha.addEventListener("blur", ()=>{validarFecha()});

const nombre = document.getElementById("nombre");
nombre.addEventListener("blur", ()=>{validarNombre()});


const destinatario = document.getElementById("destinatario");
destinatario.addEventListener("blur",()=>{validarDestinatario()});

const gramos = document.getElementById("gramos");
gramos.addEventListener("blur", ()=>{validarGramos()});

const composicion = document.getElementById("composicion");
composicion.addEventListener("blur", ()=>{validarComposicion()});

const cuenta = document.getElementById("cuenta");
cuenta.addEventListener("blur", ()=>{validarCuenta()});

const error = document.getElementById("error");

function validarNombre() {
   const patron = /^[A-Z]{2,2}[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]{1,1}[0-9]{4,4}$/;
   if(nombre.value.match(patron)){
    error.innerHTML = "";
   }else{
    error.innerHTML = "Debe tener dos letras en mayúscula, un símbolo y cuatro dígitos.";
   }
}

function validarDestinatario() {
    const patron = /[A-Z]{2,3}[_]{1}[a-aA-Z]{}[:]{1}[0-9]{4,4}/;
    if(destinatario.value.match(patron)){
        error.innerHTML = "";
    }
    else{
        error.innerHTML = "Debe estar formado por dos o tres mayúsculas, un guion, dos puntos( : ) y 4 números";
    }
}

function validarGramos() {
    if(gramos.value >=100 && gramos.value <= 5000) {
        error.innerHTML = "";
    }
    else {
        error.innerHTML = "El número debe estar en un rango de entre 100 y 5000.";
    }
}

function validarComposicion() {
    const patron = /^[a-zA-Z]{1,2}[0-9]{0,1}$/;
    if(composicion.value.match(patron)){
        error.innerHTML = "";
    }
    else{
        error.innerHTML = "Debe tener una o dos letras y puede tener o no un número.";
    }
}

function validarFecha() {
    const patron = /^[0-9]{1,2}[/]{1,1}[0-9]{1,2}[/]{1,1}[0-9]{4,4}$/;
    if(fecha.value.match(patron)) {
        error.innerHTML = "";
    }else{
        error.innerHTML = "Debe tener formato fecha.";
    }
}

function validarCuenta() {
    const patron = /^[A-Za-z]{2,2}[0-9]{1,1}[-]{1,1}[0-9]{12,12}[-][0-9]{2,2}$/;
    if(cuenta.value.match(patron)) {
        cuenta.value.replaceAll('-', ' ');
        cuenta.value = cuenta.value.replaceAll('-', ' ');
        error.innerHTML = "";
    }else{
        error.innerHTML = "Debe tener formato cuenta.";
    }
}

function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    let expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  
  function getCookie(cname) {
    let name = cname + "=";
    let ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
  console.log(getCookie("marco"));
  let enviar = document.getElementById("enviar");
  //CREAMOS LA COOKIE 
  
  if(getCookie("marco") == 'NaN'){
        setCookie("marco",0,365);
  }
 
  

  enviar.addEventListener("click",()=>{
    let contador = (parseInt(getCookie("marco"))+1);
    setCookie("marco",contador,365);
    document.getElementById("contador").innerHTML = "Intentos: " + getCookie("marco");
    console.log(getCookie("marco"));
  });

 function checkCookie() {
    let user = getCookie("username");
    if (user != "") {
      alert("Welcome again " + user);
    } else {
      user = prompt("Please enter your name:", "");
      if (user != "" && user != null) {
        setCookie("username", user, 365);
      }
    }
  }
  