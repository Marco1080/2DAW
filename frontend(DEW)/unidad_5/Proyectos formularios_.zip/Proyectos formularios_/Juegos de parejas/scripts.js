let botonesMostrados = 0;
let boton1 = null;
let boton2 = null;
let resultado1 = null;
let resultado2 = null;
let puntuacion =  document.getElementById("puntuacion");
let puntos = 0;

//let numeros = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8]
let numeros = ['&#11088','&#11088','&#128225','&#128225','&#127769','&#127769','&#127761','&#127761',
                '&#128640','&#128640','&#128752','&#128752','&#129680','&#129680','&#127765','&#127765']
numeros = numeros.sort(()=>{return Math.random()-0.5});

function destapar(id){
    botonesMostrados++;
    switch(botonesMostrados){
        case 1: boton1 = document.getElementById(id);
        
                resultado1 = numeros[id];
                boton1.innerHTML = resultado1;

                boton1.disabled = true;
                break;

        case 2: boton2 = document.getElementById(id);
                resultado2 = numeros[id];

                
                boton2.innerHTML = resultado2;
                botonesMostrados++;

                boton2.disabled = true;
                botonesMostrados = 0;
                
                if(resultado1 == resultado2){
                    puntos++;
                    puntuacion.innerHTML = `Puntuacion: ${puntos}`;
                    if(puntos == 8){
                        document.getElementById("result").innerHTML="<center><p>Has ganado</p><br><button class='nuevo' onclick='location. reload()'>"
                        + "Jugar de nuevo</button></center>";

                    }
                }else{
                    setTimeout(()=>{
                        boton1.innerHTML="";
                        boton1.disabled = false;

                        boton2.innerHTML="";
                        boton2.disabled = false;
                    },700);
                }
                break;
    }
}