class test{
    constructor(cuestion,preguntas,solucion,estado){
        this.cuestion = cuestion;
        this.preguntas = preguntas;
        this.solucion = solucion;
        this.estado = estado;
    }
}

let list = []; //CONTIENE UNA LISTA CON TODOS LOS OBJETOS DE LAS PREGUNTAS

let test1 = new test("p.1.- ¿Que personaje sale en Arcane?",["Jinx", "Jhin", "Jax"],"0",false);
list.push(test1);

let test2 = new test("p2 ¿Cuántos capítulos tiene la primera temporada?",["9", "1", "20"],"0",false);
list.push(test2);

let test3 = new test("p3 ¿A que juego pertenece el mundo de Arcane?",["Valorant", "League Of Legends", "Overwatch"],"1",false);
list.push(test3);

let test4 = new test("p4 ¿Es buena serie?",["No", "Sí", "Puede"],"1",false);
list.push(test4);

let test5 = new test("p5 ¿Respondiste si a la anterior pregunta?",["No", "Debo mirar", "Sí"],"2",false);
list.push(test5);

let container = document.getElementById("container");
testMaker();

function testMaker(){
    container.innerHTML = "<h1>ARCANE</h1>";
    for(let y = 0; y < list.length; y++){
        let contador = 0;
        container.innerHTML += "<br><br>"+list[y].cuestion;
        for(let i = 0; i < 3; i++){
            texto = list[0].pregunta + i;
            container.innerHTML += `<br><label><input type=\"radio\" value=${contador} id=${y} name=${y}>${list[y].preguntas[i]}</label>`;
            contador++;
        }
        container.innerHTML += `<br><div id=\"sol${y}\"></div>`;
    }
}

let result = document.getElementById("result").addEventListener("click",validateAnswer);

function validateAnswer(){
    for(let i = 0; i < list.length; i++){
            for(let y = 0; y < 3; y++){
                let elements = document.getElementsByName(i);
                if(elements[y].checked && elements[y].value == list[i].solucion){
                    list[i].estado = true;
                }
            }
    }
    puntuar();
}
function puntuar(){
    let puntos = 0;
    for(let i = 0; i < list.length; i++){
        if(list[i].estado == true){
            puntos++;
            document.getElementById("sol"+i).innerHTML = "";
        }
        else{
            document.getElementById("sol"+i).innerHTML = `<span style='font-size:32px;'>&#10060;La respuesta ${i} es erronea`;
        }
    }
    console.log("Puntos: " + puntos);
    if(puntos == 5){
        container.innerHTML += "<br>Puntos: 10<br>Todas las preguntas han sido correctamente respondidas";
    }
}
