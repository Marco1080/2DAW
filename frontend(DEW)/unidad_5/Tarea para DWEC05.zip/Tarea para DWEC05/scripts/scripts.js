document.cookie="Intentos=0";//CREAR COOKIE

result = 0;

let formulario = document.getElementById("formulario");
let intentos = document.getElementById("intentos");


let enviar = document.getElementById("enviar");
enviar.addEventListener("click", numeroIntentos);

let errores = document.getElementById("errores");
let nombre = document.getElementById("nombre");
let apellidos = document.getElementById("apellidos");
let edad = document.getElementById("edad");
let nif = document.getElementById("nif");
let email = document.getElementById("email");
let provincia = document.getElementById("provincia");
let fecha = document.getElementById("fecha");
let telefono = document.getElementById("telefono");
let hora = document.getElementById("hora");

stringToUpper(nombre);
stringToUpper(apellidos);

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

  function setCookie(cvalue) {
    document.cookie=`Intentos= ${cvalue}`;
  }

//CAMBIAMOS EL ACTION A FALSE PARA QUE NO NOS REDIRIJA
  function cerrarSubmit(){
    formulario.onsubmit = function() {
        return false;
    };
  }
  cerrarSubmit();

  function numeroIntentos(){
    result +=1;
    setCookie(result);//ESTABLECEMOS VALOR DE LA COOKIE
    let cookieValue = getCookie("Intentos");//RECUPERAMOS VALOR DE LA COOKIE EN DONDE NOMBRE SEA'INTENTOS'

    intentos.innerHTML = "Número de intentos: " + cookieValue;
  }

//CONVIERTE LOS INPUTS EN MAYUSCULA
function stringToUpper(x){
    x.addEventListener("blur", ()=>{x.value = x.value.toUpperCase()});
}

stringValidate(nombre.value);

//VALIDAR INPUTS TIPO STRING
function stringValidate(y){
    if(isNaN(y.value) == false){
        y.focus();
        errores.innerHTML += y.value + " debe contener un valor no númerico.";
    }
}

//VALIDAR INPUT ENTRE 0 Y 105
edad.addEventListener("blur", ()=>ageValidate());
function ageValidate(){
    if(edad.value<=0 || edad.value >=105){
      edad.focus();
      errores.innerHTML = "Debe ingresar un número comprendido entre 0 y 105";
    }else{
      errores.innerHTML = "";
    }
}

nif.addEventListener("blur", ()=>dniValidate());
//VALIDAR INPUT DNI
function dniValidate(){
  if( nif.value.length == 9){
    if( isNaN(nif.value[8]) ){
      let num = (nif.value.slice(0, 8));
      if(!isNaN(num)){
        errores.innerHTML = "";
      }
    }
  }else{
    errores.innerHTML = "Debe introducir 9 número y una letra al final.";
        nif.focus();
  }
  
}
email.addEventListener("blur", ()=>{
  mailValite(email.value);
});
//VALIDAR INPUT CORREO
function mailValite(text){
  const patron = /[A-Za-z0-1]+@+gmail|hotmail+.com|.es/;
  const result = text.match(patron);
    if( result == null){
      errores.innerHTML = "EL correo introducido no es adecuado.";
      email.focus();
    }
    else{
      errores.innerHTML = "";
    }
}

fecha.addEventListener("blur", ()=>{dateValidate()});
//VALIDAR INPUT DATE
function dateValidate(){
  const patron = /[0-9]{1,2}\/[0-9]{1,2}\/[0-9]{2,4}$/;
  const result = fecha.value.match(patron);
    if( result == null){
      fecha.focus();
      errores.innerHTML = "El formato debe ser XX/YY/ZZZZ";
    }
    else{
      errores.innerHTML = "";
    }
}
telefono.addEventListener("blur", ()=>{phoneNumberValidate()});
function phoneNumberValidate(){
  const patron = /(\d{9,9})/;
  const result = telefono.value.match(patron);
  if(result == null){
    errores.innerHTML = "El formato debe ser 123456789";
    telefono.focus;
  }
  else{
    errores.innerHTML = "";
  }
}
hora.addEventListener("blur", ()=>{hourValidate()});
function hourValidate(){
  const patron = /(\d{2,2}):\d{2,2}/;
  const result = hora.value.match(patron);
  if(result == null){
    errores.innerHTML = "El de hora debe ser hh:mm";
    hora.focus();
  }
  else{
    errores.innerHTML = " ";
  }
}
provincia.addEventListener("change",()=>{provinciaValidate()});
function provinciaValidate(){
  let v = provincia.value;
  switch(v){
    case "0":
      break;
    case "C": console.log("C");
      break;
    case "LU":
      break;
    case "OU":
      break;
    default:  console.log("mal");
      break;
  }
}
enviar.addEventListener("click",()=>{sendForm()});
function sendForm(){
  if(nombre.value!="" && apellidos.value!="" && edad.value!=""
    && nif.value!="" && email.value!="" && provincia.value!=""
    &&fecha.value!="" && telefono.value!="" && telefono!=""){
    prompt("Escriba CONFIRMAR para enviar el formulario.");
  }
}